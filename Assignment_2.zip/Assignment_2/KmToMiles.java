public class KmToMiles {
    public static void main(String[] args) {
        double kilometers = 10.8;
        double miles = kilometers * 0.621371;

        System.out.println(kilometers + " kilometers is equal to " + miles + " miles");
    }
}
