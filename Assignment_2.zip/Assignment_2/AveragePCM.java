public class AveragePCM {
    public static void main(String[] args) {
        int maths = 94, physics = 95, chemistry = 96;
        double average = (maths + physics + chemistry) / 3.0;
        System.out.println("Average percentage in PCM: " + average + "%");
    }
}
